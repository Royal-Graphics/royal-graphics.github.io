I wouldn't mess with any of the folders unless you know what you're doing. Also credit to Matt RBX for making the player rig, we just
rigged the armour to the actual character armature.

Matt RBX: